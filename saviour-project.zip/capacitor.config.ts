import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.socialchatcalls.app',
  appName: 'saviour',
  webDir: 'dist'
};

export default config;
