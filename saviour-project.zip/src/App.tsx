import React from "react";
import { AppProvider, useApp } from "./context/AppContext";
import { Navbar } from "./components/Navbar";
import { Sidebar } from "./components/Sidebar";
import { FeedView } from "./components/FeedView";
import { ChatsView } from "./components/ChatsView";
import { CallsView } from "./components/CallsView";
import { PeopleView } from "./components/PeopleView";
import { ProfileView } from "./components/ProfileView";
import { ActiveCallModal } from "./components/ActiveCallModal";
import { IncomingCallDialog } from "./components/IncomingCallDialog";

const MainLayout: React.FC = () => {
  const { activeTab } = useApp();

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-slate-200 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar />

      {/* Content Container */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex flex-col md:flex-row gap-4 p-3 md:p-6">
        {/* Navigation Sidebar */}
        <Sidebar />

        {/* Main View Area */}
        <main className="flex-1 min-w-0">
          {activeTab === 'feed' && <FeedView />}
          {activeTab === 'chats' && <ChatsView />}
          {activeTab === 'calls' && <CallsView />}
          {activeTab === 'people' && <PeopleView />}
          {activeTab === 'profile' && <ProfileView />}
        </main>
      </div>

      {/* Global Overlays */}
      <ActiveCallModal />
      <IncomingCallDialog />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
