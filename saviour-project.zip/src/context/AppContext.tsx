import React, { createContext, useContext, useState, useEffect, useRef } from "react";
import { User, Story, Post, ChatMessage, CallRecord, ActiveCallState, WebSocketPayload } from "../types";
import { sounds } from "../utils/audio";

interface AppContextType {
  currentUser: User;
  users: User[];
  stories: Story[];
  posts: Post[];
  messages: Record<string, ChatMessage[]>;
  callLogs: CallRecord[];
  activeTab: 'feed' | 'chats' | 'calls' | 'people' | 'profile';
  setActiveTab: (tab: 'feed' | 'chats' | 'calls' | 'people' | 'profile') => void;
  activeConversationUserId: string | null;
  setActiveConversationUserId: (userId: string | null) => void;
  activeCall: ActiveCallState | null;
  incomingCall: ActiveCallState | null;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  switchUser: (userId: string) => void;
  createPost: (content: string, imageUrl?: string, tags?: string[]) => Promise<void>;
  likePost: (postId: string) => Promise<void>;
  addComment: (postId: string, text: string) => Promise<void>;
  sendMessage: (receiverId: string, text?: string, mediaUrl?: string, audioUrl?: string) => void;
  initiateCall: (peerId: string, type: 'audio' | 'video') => void;
  acceptIncomingCall: () => void;
  declineIncomingCall: () => void;
  endCall: () => void;
  toggleMic: () => void;
  toggleVideo: () => void;
  selectedProfileUserId: string | null;
  setSelectedProfileUserId: (userId: string | null) => void;
  wsConnected: boolean;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string>("user-1");
  const [stories, setStories] = useState<Story[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>({});
  const [callLogs, setCallLogs] = useState<CallRecord[]>([]);
  
  const [activeTab, setActiveTab] = useState<'feed' | 'chats' | 'calls' | 'people' | 'profile'>('feed');
  const [activeConversationUserId, setActiveConversationUserId] = useState<string | null>("user-2");
  const [selectedProfileUserId, setSelectedProfileUserId] = useState<string | null>(null);

  // Calling & Media States
  const [activeCall, setActiveCall] = useState<ActiveCallState | null>(null);
  const [incomingCall, setIncomingCall] = useState<ActiveCallState | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [wsConnected, setWsConnected] = useState<boolean>(false);

  const wsRef = useRef<WebSocket | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);

  const currentUser = users.find((u) => u.id === currentUserId) || {
    id: "user-1",
    name: "Alex Rivera",
    username: "alex_r",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250",
    status: "online",
    bio: "Product Designer & Tech Explorer 🚀",
    followersCount: 1420,
    followingCount: 380,
  };

  // Fetch initial data
  useEffect(() => {
    fetch("/api/initial-data")
      .then((res) => res.json())
      .then((data) => {
        setUsers(data.users || []);
        setStories(data.stories || []);
        setPosts(data.posts || []);
        setMessages(data.messages || {});
        setCallLogs(data.callLogs || []);
      })
      .catch((err) => console.error("Failed to load initial data", err));
  }, []);

  // Connect WebSocket
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    let socket: WebSocket;
    
    const connectWS = () => {
      socket = new WebSocket(wsUrl);
      wsRef.current = socket;

      socket.onopen = () => {
        setWsConnected(true);
        // Register current user
        socket.send(JSON.stringify({ type: "register", userId: currentUserId }));
      };

      socket.onmessage = (event) => {
        try {
          const payload: WebSocketPayload = JSON.parse(event.data);
          handleWebSocketMessage(payload);
        } catch (e) {
          console.error("Error parsing WS message:", e);
        }
      };

      socket.onclose = () => {
        setWsConnected(false);
        // Reconnect attempt after delay
        setTimeout(connectWS, 3000);
      };
    };

    connectWS();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [currentUserId]);

  // Handle Incoming WebSocket Messages
  const handleWebSocketMessage = async (payload: WebSocketPayload) => {
    switch (payload.type) {
      case "chat_message": {
        const msg = payload.message;
        sounds.playMessagePop();

        const key1 = `${msg.senderId}_${msg.receiverId}`;
        const key2 = `${msg.receiverId}_${msg.senderId}`;

        setMessages((prev) => {
          const list1 = prev[key1] ? [...prev[key1], msg] : [msg];
          const list2 = prev[key2] ? [...prev[key2], msg] : [msg];
          return { ...prev, [key1]: list1, [key2]: list2 };
        });
        break;
      }

      case "post_created": {
        setPosts((prev) => {
          if (prev.some((p) => p.id === payload.post.id)) return prev;
          return [payload.post, ...prev];
        });
        break;
      }

      case "post_liked": {
        setPosts((prev) =>
          prev.map((p) => {
            if (p.id === payload.postId) {
              const liked = p.likes.includes(payload.userId);
              const newLikes = liked
                ? p.likes.filter((id) => id !== payload.userId)
                : [...p.likes, payload.userId];
              return { ...p, likes: newLikes };
            }
            return p;
          })
        );
        break;
      }

      case "comment_added": {
        setPosts((prev) =>
          prev.map((p) => {
            if (p.id === payload.postId) {
              return { ...p, comments: [...p.comments, payload.comment] };
            }
            return p;
          })
        );
        break;
      }

      case "status_changed": {
        setUsers((prev) =>
          prev.map((u) => (u.id === payload.userId ? { ...u, status: payload.status } : u))
        );
        break;
      }

      // WebRTC & Calling Events
      case "call_initiate": {
        const caller = users.find((u) => u.id === payload.callerId) || {
          id: payload.callerId,
          name: "Incoming Call",
          username: "user",
          avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250",
          status: "online",
          bio: "",
          followersCount: 0,
          followingCount: 0,
        };

        sounds.startIncomingRingtone();

        setIncomingCall({
          callId: payload.callId,
          peerId: caller.id,
          peerName: caller.name,
          peerAvatar: caller.avatar,
          type: payload.callType,
          isIncoming: true,
          status: "ringing",
        });
        break;
      }

      case "call_accept": {
        sounds.stopRingtone();
        sounds.playConnectSound();

        setActiveCall((prev) => (prev ? { ...prev, status: "connected", startTime: Date.now() } : null));

        // Create WebRTC offer if caller
        setupWebRTCPeerConnection(payload.peerId, true, payload.callId);
        break;
      }

      case "call_decline":
      case "call_end": {
        sounds.stopRingtone();
        sounds.playEndSound();

        cleanupCallState();
        break;
      }

      case "webrtc_signal": {
        handleWebRTCSignal(payload.signal, payload.targetUserId, payload.callId);
        break;
      }
    }
  };

  // Setup WebRTC PeerConnection
  const setupWebRTCPeerConnection = async (peerId: string, isInitiator: boolean, callId: string) => {
    try {
      const pc = new RTCPeerConnection({
        iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
      });
      peerConnectionRef.current = pc;

      // Handle remote tracks
      const remote = new MediaStream();
      setRemoteStream(remote);

      pc.ontrack = (event) => {
        event.streams[0].getTracks().forEach((track) => {
          remote.addTrack(track);
        });
      };

      // Handle ICE Candidates
      pc.onicecandidate = (event) => {
        if (event.candidate && wsRef.current) {
          wsRef.current.send(
            JSON.stringify({
              type: "webrtc_signal",
              callId,
              targetUserId: peerId,
              signal: { candidate: event.candidate },
            })
          );
        }
      };

      // Request User Media
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: activeCall?.type === "video" || incomingCall?.type === "video",
      });

      setLocalStream(stream);
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      if (isInitiator) {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        if (wsRef.current) {
          wsRef.current.send(
            JSON.stringify({
              type: "webrtc_signal",
              callId,
              targetUserId: peerId,
              signal: { sdp: pc.localDescription },
            })
          );
        }
      }
    } catch (err) {
      console.error("WebRTC Setup error (mic/camera access or signaling)", err);
    }
  };

  const handleWebRTCSignal = async (signal: any, senderId: string, callId: string) => {
    let pc = peerConnectionRef.current;
    if (!pc) {
      pc = new RTCPeerConnection({
        iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
      });
      peerConnectionRef.current = pc;
    }

    if (signal.sdp) {
      await pc.setRemoteDescription(new RTCSessionDescription(signal.sdp));
      if (signal.sdp.type === "offer") {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: activeCall?.type === "video" || incomingCall?.type === "video",
        });
        setLocalStream(stream);
        stream.getTracks().forEach((track) => pc.addTrack(track, stream));

        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        if (wsRef.current) {
          wsRef.current.send(
            JSON.stringify({
              type: "webrtc_signal",
              callId,
              targetUserId: senderId,
              signal: { sdp: pc.localDescription },
            })
          );
        }
      }
    } else if (signal.candidate) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(signal.candidate));
      } catch (e) {
        console.error("Error adding ICE candidate", e);
      }
    }
  };

  const initiateCall = (peerId: string, type: 'audio' | 'video') => {
    const peer = users.find((u) => u.id === peerId);
    if (!peer) return;

    const callId = "call-" + Date.now();
    sounds.startOutgoingRingtone();

    const newCallState: ActiveCallState = {
      callId,
      peerId,
      peerName: peer.name,
      peerAvatar: peer.avatar,
      type,
      isIncoming: false,
      status: "ringing",
    };

    setActiveCall(newCallState);

    // Send call initiation over socket
    if (wsRef.current) {
      wsRef.current.send(
        JSON.stringify({
          type: "call_initiate",
          callId,
          callerId: currentUserId,
          receiverId: peerId,
          callType: type,
        })
      );
    }

    // AI Buddy Call special simulation if calling AI
    if (peer.isAi) {
      setTimeout(() => {
        sounds.stopRingtone();
        sounds.playConnectSound();
        setActiveCall({
          ...newCallState,
          status: "connected",
          startTime: Date.now(),
        });
      }, 2000);
    }
  };

  const acceptIncomingCall = () => {
    if (!incomingCall) return;
    sounds.stopRingtone();
    sounds.playConnectSound();

    const callState: ActiveCallState = {
      ...incomingCall,
      status: "connected",
      startTime: Date.now(),
    };

    setActiveCall(callState);
    setIncomingCall(null);

    if (wsRef.current) {
      wsRef.current.send(
        JSON.stringify({
          type: "call_accept",
          callId: incomingCall.callId,
          peerId: incomingCall.peerId,
        })
      );
    }

    setupWebRTCPeerConnection(incomingCall.peerId, false, incomingCall.callId);
  };

  const declineIncomingCall = () => {
    if (!incomingCall) return;
    sounds.stopRingtone();
    sounds.playEndSound();

    if (wsRef.current) {
      wsRef.current.send(
        JSON.stringify({
          type: "call_decline",
          callId: incomingCall.callId,
          peerId: incomingCall.peerId,
        })
      );
    }

    setIncomingCall(null);
  };

  const endCall = () => {
    sounds.stopRingtone();
    sounds.playEndSound();

    if (activeCall && wsRef.current) {
      wsRef.current.send(
        JSON.stringify({
          type: "call_end",
          callId: activeCall.callId,
          peerId: activeCall.peerId,
        })
      );

      // Add to call logs
      const duration = activeCall.startTime ? Math.floor((Date.now() - activeCall.startTime) / 1000) : 0;
      setCallLogs((prev) => [
        {
          id: activeCall.callId,
          callerId: activeCall.isIncoming ? activeCall.peerId : currentUserId,
          receiverId: activeCall.isIncoming ? currentUserId : activeCall.peerId,
          type: activeCall.type,
          status: "completed",
          durationSeconds: duration,
          timestamp: "Just now",
        },
        ...prev,
      ]);
    }

    cleanupCallState();
  };

  const cleanupCallState = () => {
    setActiveCall(null);
    setIncomingCall(null);

    if (localStream) {
      localStream.getTracks().forEach((t) => t.stop());
      setLocalStream(null);
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }
    setRemoteStream(null);
  };

  const toggleMic = () => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setActiveCall((prev) => (prev ? { ...prev, isMicMuted: !audioTrack.enabled } : null));
      }
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setActiveCall((prev) => (prev ? { ...prev, isVideoOff: !videoTrack.enabled } : null));
      }
    }
  };

  const switchUser = (userId: string) => {
    setCurrentUserId(userId);
  };

  const createPost = async (content: string, imageUrl?: string, tags?: string[]) => {
    const newPost: Post = {
      id: "post-" + Date.now(),
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      content,
      imageUrl,
      likes: [],
      comments: [],
      sharesCount: 0,
      timestamp: "Just now",
      tags: tags || [],
    };

    setPosts((prev) => [newPost, ...prev]);

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: "post_created", post: newPost }));
    } else {
      fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newPost),
      });
    }
  };

  const likePost = async (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const liked = p.likes.includes(currentUser.id);
          const newLikes = liked
            ? p.likes.filter((id) => id !== currentUser.id)
            : [...p.likes, currentUser.id];
          return { ...p, likes: newLikes };
        }
        return p;
      })
    );

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({ type: "post_liked", postId, userId: currentUser.id })
      );
    }
  };

  const addComment = async (postId: string, text: string) => {
    const comment = {
      id: "c-" + Date.now(),
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      text,
      timestamp: "Just now",
    };

    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, comments: [...p.comments, comment] } : p))
    );

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({ type: "comment_added", postId, comment })
      );
    }
  };

  const sendMessage = (receiverId: string, text?: string, mediaUrl?: string, audioUrl?: string) => {
    const msg: ChatMessage = {
      id: "msg-" + Date.now(),
      senderId: currentUser.id,
      receiverId,
      text,
      mediaUrl,
      audioUrl,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: "delivered",
    };

    const key1 = `${currentUser.id}_${receiverId}`;
    const key2 = `${receiverId}_${currentUser.id}`;

    setMessages((prev) => {
      const list1 = prev[key1] ? [...prev[key1], msg] : [msg];
      const list2 = prev[key2] ? [...prev[key2], msg] : [msg];
      return { ...prev, [key1]: list1, [key2]: list2 };
    });

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: "chat_message", message: msg }));
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        stories,
        posts,
        messages,
        callLogs,
        activeTab,
        setActiveTab,
        activeConversationUserId,
        setActiveConversationUserId,
        activeCall,
        incomingCall,
        localStream,
        remoteStream,
        switchUser,
        createPost,
        likePost,
        addComment,
        sendMessage,
        initiateCall,
        acceptIncomingCall,
        declineIncomingCall,
        endCall,
        toggleMic,
        toggleVideo,
        selectedProfileUserId,
        setSelectedProfileUserId,
        wsConnected,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
};
