export interface User {
  id: string;
  name: string;
  username: string;
  avatar: string;
  status: 'online' | 'offline' | 'in-call' | 'away';
  bio: string;
  followersCount: number;
  followingCount: number;
  isAi?: boolean;
}

export interface Story {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  mediaUrl: string;
  caption?: string;
  timestamp: string;
  viewed?: boolean;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  timestamp: string;
}

export interface Post {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  imageUrl?: string;
  likes: string[]; // array of userIds
  comments: Comment[];
  sharesCount: number;
  timestamp: string;
  tags?: string[];
}

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId: string;
  text?: string;
  mediaUrl?: string;
  audioUrl?: string; // for voice notes
  timestamp: string;
  reactions?: Record<string, string>; // userId -> emoji
  status?: 'sent' | 'delivered' | 'read';
}

export interface Conversation {
  id: string; // usually combination of user ids or group id
  participants: string[]; // userIds
  lastMessage?: ChatMessage;
  unreadCount?: number;
}

export interface CallRecord {
  id: string;
  callerId: string;
  receiverId: string;
  type: 'audio' | 'video';
  status: 'completed' | 'missed' | 'rejected';
  durationSeconds: number;
  timestamp: string;
}

export interface ActiveCallState {
  callId: string;
  peerId: string; // The user ID on the other end
  peerName: string;
  peerAvatar: string;
  type: 'audio' | 'video';
  isIncoming: boolean;
  status: 'dialing' | 'ringing' | 'connected' | 'ended';
  startTime?: number;
  isMicMuted?: boolean;
  isVideoOff?: boolean;
  isScreenSharing?: boolean;
}

export type WebSocketPayload =
  | { type: 'register'; userId: string }
  | { type: 'chat_message'; message: ChatMessage }
  | { type: 'typing'; senderId: string; receiverId: string; isTyping: boolean }
  | { type: 'post_created'; post: Post }
  | { type: 'post_liked'; postId: string; userId: string }
  | { type: 'comment_added'; postId: string; comment: Comment }
  | { type: 'status_changed'; userId: string; status: User['status'] }
  | { type: 'call_initiate'; callId: string; callerId: string; receiverId: string; callType: 'audio' | 'video' }
  | { type: 'call_accept'; callId: string; peerId: string }
  | { type: 'call_decline'; callId: string; peerId: string }
  | { type: 'call_end'; callId: string; peerId: string }
  | { type: 'webrtc_signal'; callId: string; targetUserId: string; signal: any };
