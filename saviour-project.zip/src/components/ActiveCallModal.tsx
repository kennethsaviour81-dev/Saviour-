import React, { useEffect, useRef, useState } from "react";
import { useApp } from "../context/AppContext";
import { 
  Mic, 
  MicOff, 
  Video as VideoIcon, 
  VideoOff, 
  PhoneOff, 
  Monitor, 
  Sparkles, 
  Volume2, 
  VolumeX,
  Minimize2,
  Maximize2
} from "lucide-react";

export const ActiveCallModal: React.FC = () => {
  const { 
    activeCall, 
    localStream, 
    remoteStream, 
    endCall, 
    toggleMic, 
    toggleVideo 
  } = useApp();

  const [callTimer, setCallTimer] = useState(0);
  const [isMinimized, setIsMinimized] = useState(false);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  // Bind streams to video elements
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  // Call timer interval
  useEffect(() => {
    if (activeCall?.status === "connected") {
      const interval = setInterval(() => {
        setCallTimer((prev) => prev + 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [activeCall?.status]);

  if (!activeCall) return null;

  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  if (isMinimized) {
    return (
      <div className="fixed bottom-6 right-6 z-50 bg-[#161616] border border-white/10 rounded-2xl p-3 shadow-2xl flex items-center gap-3 animate-bounce">
        <img src={activeCall.peerAvatar} className="w-10 h-10 rounded-full object-cover border border-emerald-500" />
        <div>
          <h4 className="text-xs font-bold text-slate-100">{activeCall.peerName}</h4>
          <p className="text-[10px] text-emerald-400 font-mono">{formatTimer(callTimer)}</p>
        </div>

        <button
          onClick={() => setIsMinimized(false)}
          className="p-1.5 bg-white/5 text-slate-300 hover:text-white rounded-lg"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
        <button
          onClick={endCall}
          className="p-1.5 bg-red-600 text-white hover:bg-red-500 rounded-lg"
        >
          <PhoneOff className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-xl z-50 flex items-center justify-center p-4">
      <div className="relative w-full max-w-4xl bg-[#0A0A0A] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col h-[80vh]">
        
        {/* Call Header */}
        <div className="p-4 bg-[#121212] border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={activeCall.peerAvatar} className="w-10 h-10 rounded-full object-cover border border-indigo-500" />
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                {activeCall.peerName}
                {activeCall.peerId === "user-ai" && <Sparkles className="w-4 h-4 text-indigo-400" />}
              </h3>
              <p className="text-xs text-emerald-400 font-mono">
                {activeCall.status === "connected" ? `Connected (${formatTimer(callTimer)})` : "Ringing..."}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsMinimized(true)}
            className="p-2 text-slate-400 hover:text-white bg-white/5 rounded-xl"
            title="Minimize"
          >
            <Minimize2 className="w-4 h-4" />
          </button>
        </div>

        {/* Video Stage / Visualizer Area */}
        <div className="flex-1 bg-[#121212] relative flex items-center justify-center overflow-hidden">
          
          {/* Remote Video Stream or Avatar fallback */}
          {activeCall.type === "video" && remoteStream ? (
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="flex flex-col items-center gap-4 text-center">
              <div className="relative">
                <div className="w-28 h-28 rounded-full overflow-hidden border-4 border-indigo-500 shadow-2xl animate-pulse">
                  <img src={activeCall.peerAvatar} className="w-full h-full object-cover" />
                </div>
                {activeCall.status === "ringing" && (
                  <div className="absolute inset-0 rounded-full border-4 border-emerald-500 animate-ping opacity-75" />
                )}
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">{activeCall.peerName}</h2>
                <p className="text-xs text-slate-400 mt-1">
                  {activeCall.status === "connected" ? "Audio Call Connected" : "Connecting WebRTC Peer Call..."}
                </p>
              </div>
            </div>
          )}

          {/* Self Camera Picture-in-Picture */}
          {activeCall.type === "video" && localStream && (
            <div className="absolute bottom-4 right-4 w-36 h-48 bg-[#0A0A0A] border-2 border-white/10 rounded-2xl overflow-hidden shadow-2xl">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            </div>
          )}

        </div>

        {/* Call Controls Footer */}
        <div className="p-5 bg-[#121212] border-t border-white/5 flex items-center justify-center gap-4">
          
          <button
            onClick={toggleMic}
            className={`p-3.5 rounded-full font-semibold transition ${
              activeCall.isMicMuted
                ? 'bg-red-600 text-white'
                : 'bg-white/5 text-slate-200 hover:bg-white/10'
            }`}
            title={activeCall.isMicMuted ? "Unmute Mic" : "Mute Mic"}
          >
            {activeCall.isMicMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <button
            onClick={toggleVideo}
            className={`p-3.5 rounded-full font-semibold transition ${
              activeCall.isVideoOff
                ? 'bg-red-600 text-white'
                : 'bg-white/5 text-slate-200 hover:bg-white/10'
            }`}
            title={activeCall.isVideoOff ? "Turn On Camera" : "Turn Off Camera"}
          >
            {activeCall.isVideoOff ? <VideoOff className="w-5 h-5" /> : <VideoIcon className="w-5 h-5" />}
          </button>

          <button
            onClick={endCall}
            className="p-4 bg-red-600 hover:bg-red-500 text-white rounded-full shadow-lg shadow-red-600/30 transition transform hover:scale-105"
            title="End Call"
          >
            <PhoneOff className="w-6 h-6" />
          </button>

        </div>

      </div>
    </div>
  );
};
