import React from "react";
import { useApp } from "../context/AppContext";
import { 
  UserPlus, 
  MessageSquare, 
  PhoneCall, 
  Video, 
  Sparkles, 
  ArrowRightLeft,
  Check
} from "lucide-react";

export const PeopleView: React.FC = () => {
  const { 
    users, 
    currentUser, 
    switchUser, 
    setActiveConversationUserId, 
    setActiveTab,
    initiateCall,
    setSelectedProfileUserId
  } = useApp();

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      
      {/* Header Banner */}
      <div className="bg-[#121212] border border-white/5 rounded-2xl p-6 shadow-xl space-y-2">
        <h2 className="text-lg font-bold text-slate-100">People & Network</h2>
        <p className="text-xs text-slate-400">
          Discover members on Social Pulse, start chats, or initiate instant audio/video calls. Click "Switch to Account" to test real-time chat between accounts!
        </p>
      </div>

      {/* Grid of Users */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {users.map((user) => {
          const isCurrent = user.id === currentUser.id;

          return (
            <div
              key={user.id}
              className={`bg-[#121212] border p-5 rounded-2xl space-y-4 transition ${
                isCurrent ? 'border-indigo-500/50 bg-indigo-950/10' : 'border-white/5 hover:border-white/10'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div
                  className="flex items-center gap-3 cursor-pointer"
                  onClick={() => {
                    setSelectedProfileUserId(user.id);
                    setActiveTab('profile');
                  }}
                >
                  <div className="relative">
                    <img src={user.avatar} className="w-12 h-12 rounded-full object-cover border border-white/10" />
                    <span
                      className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#121212] ${
                        user.status === 'online' ? 'bg-emerald-500' : 'bg-slate-500'
                      }`}
                    />
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-slate-100 flex items-center gap-1.5 hover:underline">
                      {user.name}
                      {user.isAi && <Sparkles className="w-3.5 h-3.5 text-indigo-400" />}
                    </h3>
                    <p className="text-xs text-slate-400">@{user.username}</p>
                  </div>
                </div>

                {isCurrent ? (
                  <span className="text-[10px] font-bold text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-full border border-indigo-500/30">
                    Active Session
                  </span>
                ) : (
                  <button
                    onClick={() => switchUser(user.id)}
                    className="flex items-center gap-1 text-[11px] font-semibold text-slate-300 bg-white/5 hover:bg-white/10 px-2.5 py-1 rounded-lg border border-white/10 transition"
                    title="Impersonate user to test multi-user chat"
                  >
                    <ArrowRightLeft className="w-3 h-3 text-indigo-400" />
                    <span>Switch to</span>
                  </button>
                )}
              </div>

              <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">{user.bio}</p>

              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-white/5">
                <div className="flex items-center gap-3">
                  <span><strong>{user.followersCount}</strong> Followers</span>
                  <span><strong>{user.followingCount}</strong> Following</span>
                </div>

                {!isCurrent && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setActiveConversationUserId(user.id);
                        setActiveTab('chats');
                      }}
                      className="p-1.5 text-slate-300 hover:text-indigo-400 bg-white/5 hover:bg-white/10 rounded-lg transition"
                      title="Send Message"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => initiateCall(user.id, "audio")}
                      className="p-1.5 text-slate-300 hover:text-emerald-400 bg-white/5 hover:bg-white/10 rounded-lg transition"
                      title="Audio Call"
                    >
                      <PhoneCall className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => initiateCall(user.id, "video")}
                      className="p-1.5 text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition shadow-md"
                      title="Video Call"
                    >
                      <Video className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
