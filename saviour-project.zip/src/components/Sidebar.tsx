import React from "react";
import { useApp } from "../context/AppContext";
import { 
  Rss, 
  MessageSquare, 
  PhoneCall, 
  Users, 
  User as UserIcon, 
  Sparkles,
  Flame,
  PlusCircle
} from "lucide-react";

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, messages, currentUser, activeCall, setSelectedProfileUserId } = useApp();

  // Count unread or total active conversations
  const unreadCount = Object.keys(messages).length;

  const navItems = [
    { id: 'feed' as const, label: 'Feed & Stories', icon: Rss, badge: null },
    { id: 'chats' as const, label: 'Direct Messages', icon: MessageSquare, badge: unreadCount > 0 ? unreadCount : null },
    { id: 'calls' as const, label: 'Calls & Rooms', icon: PhoneCall, badge: activeCall ? 'Active' : null },
    { id: 'people' as const, label: 'People & Network', icon: Users, badge: null },
    { id: 'profile' as const, label: 'My Profile', icon: UserIcon, badge: null },
  ];

  return (
    <aside className="w-full md:w-64 bg-[#121212] border-r border-white/5 p-3 flex md:flex-col justify-between shrink-0">
      
      <div className="space-y-6 w-full">
        {/* Navigation Section */}
        <div className="space-y-1 w-full flex md:flex-col justify-around md:justify-start">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  if (item.id === 'profile') {
                    setSelectedProfileUserId(currentUser.id);
                  }
                  setActiveTab(item.id);
                }}
                className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <Icon className={`w-4 h-4 md:w-5 md:h-5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span className="hidden md:inline">{item.label}</span>
                {item.badge && (
                  <span className={`hidden md:inline-flex ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    item.badge === 'Active' 
                      ? 'bg-emerald-500 text-black animate-pulse' 
                      : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Quick AI Voice Buddy Call Card */}
        <div className="hidden md:block p-4 rounded-2xl bg-[#161616] border border-white/5 relative overflow-hidden">
          <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-indigo-500/10 rounded-full blur-xl pointer-events-none"></div>
          <div className="flex items-center gap-2 text-indigo-400 mb-1 font-semibold text-xs uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Voice Companion</span>
          </div>
          <p className="text-xs text-slate-300 font-medium mb-3">
            Want to test an instant audio call with Gemini AI?
          </p>
          <button
            onClick={() => {
              setActiveTab('chats');
            }}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-1.5 px-3 rounded-lg text-xs transition flex items-center justify-center gap-1.5 shadow-md"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Call Gemini AI</span>
          </button>
        </div>
      </div>

      {/* User Card at bottom of sidebar */}
      <div className="hidden md:flex items-center gap-3 p-3 bg-[#161616] rounded-xl border border-white/5">
        <img
          src={currentUser.avatar}
          alt={currentUser.name}
          className="w-9 h-9 rounded-full object-cover border border-white/10"
        />
        <div className="flex-1 min-w-0">
          <h4 className="text-xs font-semibold text-slate-200 truncate">{currentUser.name}</h4>
          <p className="text-[11px] text-slate-500 truncate">@{currentUser.username}</p>
        </div>
      </div>

    </aside>
  );
};
