import React from "react";
import { useApp } from "../context/AppContext";
import { 
  MessageSquare, 
  PhoneCall, 
  Video, 
  Sparkles, 
  MapPin, 
  Calendar, 
  Heart, 
  MessageCircle,
  Edit3
} from "lucide-react";

export const ProfileView: React.FC = () => {
  const { 
    users, 
    currentUser, 
    posts, 
    selectedProfileUserId, 
    setActiveConversationUserId, 
    setActiveTab, 
    initiateCall 
  } = useApp();

  const targetUserId = selectedProfileUserId || currentUser.id;
  const user = users.find((u) => u.id === targetUserId) || currentUser;
  const isSelf = user.id === currentUser.id;

  const userPosts = posts.filter((p) => p.userId === user.id);

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-20">
      
      {/* Cover Banner & Profile Card */}
      <div className="bg-[#121212] border border-white/5 rounded-2xl overflow-hidden shadow-xl">
        
        {/* Cover Photo */}
        <div className="h-40 bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-900 relative">
          <div className="absolute inset-0 bg-black/30" />
        </div>

        {/* Profile Info Row */}
        <div className="px-6 pb-6 relative">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 -mt-16 mb-4">
            
            <div className="relative">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-28 h-28 rounded-full object-cover border-4 border-[#121212] shadow-2xl"
              />
              <span
                className={`absolute bottom-1 right-1 w-4 h-4 rounded-full border-2 border-[#121212] ${
                  user.status === 'online' ? 'bg-emerald-500' : 'bg-slate-500'
                }`}
              />
            </div>

            {!isSelf ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setActiveConversationUserId(user.id);
                    setActiveTab('chats');
                  }}
                  className="bg-white/5 hover:bg-white/10 text-slate-200 px-3.5 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Message</span>
                </button>

                <button
                  onClick={() => initiateCall(user.id, "audio")}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white px-3.5 py-2 rounded-xl text-xs font-semibold shadow-md transition flex items-center gap-1.5"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Audio Call</span>
                </button>

                <button
                  onClick={() => initiateCall(user.id, "video")}
                  className="bg-indigo-700 hover:bg-indigo-600 text-white px-3.5 py-2 rounded-xl text-xs font-semibold shadow-md transition flex items-center gap-1.5"
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>Video Call</span>
                </button>
              </div>
            ) : (
              <button className="bg-white/5 hover:bg-white/10 text-slate-200 px-4 py-2 rounded-xl text-xs font-semibold border border-white/10 transition flex items-center gap-1.5">
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit Profile</span>
              </button>
            )}

          </div>

          <div className="space-y-3">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                {user.name}
                {user.isAi && <Sparkles className="w-4 h-4 text-indigo-400" />}
              </h2>
              <p className="text-xs text-slate-400">@{user.username}</p>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed max-w-xl">
              {user.bio}
            </p>

            <div className="flex items-center gap-6 text-xs text-slate-400 pt-2 border-t border-white/5">
              <div>
                <span className="font-bold text-white mr-1">{user.followersCount}</span>
                <span>Followers</span>
              </div>
              <div>
                <span className="font-bold text-white mr-1">{user.followingCount}</span>
                <span>Following</span>
              </div>
              <div>
                <span className="font-bold text-white mr-1">{userPosts.length}</span>
                <span>Posts</span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* User Posts Timeline */}
      <div className="space-y-4">
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
          {user.name}'s Posts & Activity
        </h3>

        {userPosts.length === 0 ? (
          <div className="bg-[#121212] border border-white/5 rounded-2xl p-8 text-center space-y-2 text-slate-500">
            <p className="text-xs">No posts published yet.</p>
          </div>
        ) : (
          userPosts.map((post) => (
            <article
              key={post.id}
              className="bg-[#121212] border border-white/5 rounded-2xl p-5 shadow-lg space-y-3"
            >
              <div className="flex items-center gap-3">
                <img src={post.userAvatar} className="w-9 h-9 rounded-full object-cover border border-white/10" />
                <div>
                  <h4 className="text-xs font-bold text-slate-100">{post.userName}</h4>
                  <p className="text-[10px] text-slate-500">{post.timestamp}</p>
                </div>
              </div>

              <p className="text-xs text-slate-200 leading-relaxed">{post.content}</p>

              {post.imageUrl && (
                <div className="rounded-xl overflow-hidden border border-white/5 max-h-80">
                  <img src={post.imageUrl} className="w-full h-full object-cover" />
                </div>
              )}

              <div className="flex items-center gap-4 text-xs text-slate-400 pt-2 border-t border-white/5">
                <span className="flex items-center gap-1">
                  <Heart className="w-3.5 h-3.5 text-pink-500" /> {post.likes.length}
                </span>
                <span className="flex items-center gap-1">
                  <MessageCircle className="w-3.5 h-3.5 text-indigo-400" /> {post.comments.length}
                </span>
              </div>
            </article>
          ))
        )}
      </div>

    </div>
  );
};
