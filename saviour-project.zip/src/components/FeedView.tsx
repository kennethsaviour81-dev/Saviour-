import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Image as ImageIcon, 
  Sparkles, 
  Send, 
  Plus, 
  Tag, 
  X,
  MoreHorizontal,
  Bookmark
} from "lucide-react";

export const FeedView: React.FC = () => {
  const { posts, stories, currentUser, createPost, likePost, addComment, setSelectedProfileUserId, setActiveTab } = useApp();

  const [postContent, setPostContent] = useState("");
  const [postImageUrl, setPostImageUrl] = useState("");
  const [showImageInput, setShowImageInput] = useState(false);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);
  const [aiTopic, setAiTopic] = useState("");
  const [showAiModal, setShowAiModal] = useState(false);

  // Active Comment Drawer
  const [activeCommentPostId, setActiveCommentPostId] = useState<string | null>(null);
  const [commentText, setCommentText] = useState("");

  // Active Story Modal
  const [activeStory, setActiveStory] = useState<any | null>(null);

  const handlePostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!postContent.trim() && !postImageUrl) return;
    await createPost(postContent, postImageUrl || undefined, ["SocialPulse"]);
    setPostContent("");
    setPostImageUrl("");
    setShowImageInput(false);
  };

  const handleGenerateAiPost = async () => {
    setIsGeneratingAi(true);
    try {
      const res = await fetch("/api/ai/generate-post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: aiTopic, style: "inspiring & casual" }),
      });
      const data = await res.json();
      setPostContent(data.text || "");
      setShowAiModal(false);
      setAiTopic("");
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleCommentSubmit = async (postId: string) => {
    if (!commentText.trim()) return;
    await addComment(postId, commentText);
    setCommentText("");
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-20">
      
      {/* Top Stories Bar */}
      <div className="bg-[#121212] border border-white/5 rounded-2xl p-4 overflow-x-auto">
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
          Stories & Live Updates
        </h3>
        <div className="flex items-center gap-4 min-w-max">
          
          {/* Create Story Circle */}
          <div className="flex flex-col items-center gap-1.5 cursor-pointer group">
            <div className="w-14 h-14 rounded-full bg-[#161616] border-2 border-dashed border-indigo-500/60 flex items-center justify-center text-indigo-400 group-hover:scale-105 transition">
              <Plus className="w-6 h-6" />
            </div>
            <span className="text-[11px] text-slate-300 font-medium">Your Story</span>
          </div>

          {/* User Stories */}
          {stories.map((story) => (
            <div
              key={story.id}
              onClick={() => setActiveStory(story)}
              className="flex flex-col items-center gap-1.5 cursor-pointer group"
            >
              <div className="w-14 h-14 rounded-full p-0.5 bg-indigo-600 group-hover:scale-105 transition shadow-md">
                <img
                  src={story.userAvatar}
                  alt={story.userName}
                  className="w-full h-full rounded-full object-cover border-2 border-[#121212]"
                />
              </div>
              <span className="text-[11px] text-slate-300 font-medium truncate max-w-[64px]">
                {story.userName.split(" ")[0]}
              </span>
            </div>
          ))}

        </div>
      </div>

      {/* Post Creator Box */}
      <div className="bg-[#121212] border border-white/5 rounded-2xl p-4 shadow-xl relative">
        <form onSubmit={handlePostSubmit} className="space-y-3">
          <div className="flex items-start gap-3">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-10 h-10 rounded-full object-cover border border-white/10"
            />
            <textarea
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              placeholder={`What's on your mind, ${currentUser.name.split(" ")[0]}?`}
              className="w-full bg-transparent border-none text-sm text-slate-100 placeholder-slate-500 focus:outline-none resize-none min-h-[70px]"
            />
          </div>

          {/* Optional Image URL preview or input */}
          {showImageInput && (
            <div className="flex items-center gap-2 bg-[#161616] p-2 rounded-xl border border-white/5">
              <ImageIcon className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={postImageUrl}
                onChange={(e) => setPostImageUrl(e.target.value)}
                placeholder="Paste image URL..."
                className="w-full bg-transparent text-xs text-slate-200 placeholder-slate-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowImageInput(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {postImageUrl && (
            <div className="relative rounded-xl overflow-hidden max-h-48 border border-white/5">
              <img src={postImageUrl} alt="Preview" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => setPostImageUrl("")}
                className="absolute top-2 right-2 bg-black/60 text-white p-1 rounded-full hover:bg-black/80"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Action Bar */}
          <div className="flex items-center justify-between pt-2 border-t border-white/5">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowImageInput(!showImageInput)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-white/5 transition"
              >
                <ImageIcon className="w-4 h-4 text-emerald-400" />
                <span>Photo</span>
              </button>

              <button
                type="button"
                onClick={() => setShowAiModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-indigo-400 hover:bg-indigo-500/10 transition border border-indigo-500/20"
              >
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <span>AI Draft</span>
              </button>
            </div>

            <button
              type="submit"
              disabled={!postContent.trim() && !postImageUrl}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white px-4 py-1.5 rounded-xl text-xs font-semibold shadow-md shadow-indigo-600/20 transition flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Post</span>
            </button>
          </div>
        </form>
      </div>

      {/* AI Post Draft Modal */}
      {showAiModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#161616] border border-white/10 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-indigo-400 font-semibold text-sm">
                <Sparkles className="w-4 h-4" />
                <span>Generate Post with Gemini AI</span>
              </div>
              <button onClick={() => setShowAiModal(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Enter a topic or idea, and Gemini will compose a social media update for you!
            </p>

            <input
              type="text"
              value={aiTopic}
              onChange={(e) => setAiTopic(e.target.value)}
              placeholder="e.g. Launching a new WebRTC audio calling app..."
              className="w-full bg-[#121212] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowAiModal(false)}
                className="px-3 py-1.5 rounded-xl text-xs text-slate-400 hover:bg-white/5"
              >
                Cancel
              </button>
              <button
                onClick={handleGenerateAiPost}
                disabled={isGeneratingAi || !aiTopic.trim()}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2"
              >
                {isGeneratingAi ? (
                  <>
                    <Sparkles className="w-3.5 h-3.5 animate-spin" />
                    <span>Writing...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Generate Draft</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Posts Feed */}
      <div className="space-y-4">
        {posts.map((post) => {
          const isLiked = post.likes.includes(currentUser.id);

          return (
            <article
              key={post.id}
              className="bg-[#121212] border border-white/5 rounded-2xl p-5 shadow-lg space-y-4 transition hover:border-white/10"
            >
              {/* Header */}
              <div className="flex items-center justify-between">
                <div
                  className="flex items-center gap-3 cursor-pointer"
                  onClick={() => {
                    setSelectedProfileUserId(post.userId);
                    setActiveTab('profile');
                  }}
                >
                  <img
                    src={post.userAvatar}
                    alt={post.userName}
                    className="w-10 h-10 rounded-full object-cover border border-white/10"
                  />
                  <div>
                    <h4 className="text-xs font-bold text-slate-100 hover:underline">
                      {post.userName}
                    </h4>
                    <p className="text-[11px] text-slate-500">{post.timestamp}</p>
                  </div>
                </div>

                <button className="text-slate-500 hover:text-slate-300">
                  <MoreHorizontal className="w-4 h-4" />
                </button>
              </div>

              {/* Text Content */}
              <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-normal">
                {post.content}
              </p>

              {/* Optional Tags */}
              {post.tags && post.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {post.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-md font-medium border border-indigo-500/20"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Optional Post Image */}
              {post.imageUrl && (
                <div className="rounded-xl overflow-hidden border border-white/5 max-h-96">
                  <img src={post.imageUrl} alt="Post content" className="w-full h-full object-cover" />
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-white/5 text-xs text-slate-400">
                
                <button
                  onClick={() => likePost(post.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${
                    isLiked ? 'text-pink-500 bg-pink-500/10 font-medium' : 'hover:bg-white/5 hover:text-slate-200'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'fill-pink-500 text-pink-500' : ''}`} />
                  <span>{post.likes.length}</span>
                </button>

                <button
                  onClick={() =>
                    setActiveCommentPostId(activeCommentPostId === post.id ? null : post.id)
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-white/5 hover:text-slate-200 transition"
                >
                  <MessageCircle className="w-4 h-4 text-indigo-400" />
                  <span>{post.comments.length} Comments</span>
                </button>

                <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-white/5 hover:text-slate-200 transition">
                  <Share2 className="w-4 h-4" />
                  <span>Share</span>
                </button>

              </div>

              {/* Comment Drawer */}
              {activeCommentPostId === post.id && (
                <div className="pt-3 border-t border-white/5 space-y-3">
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {post.comments.length === 0 ? (
                      <p className="text-[11px] text-slate-500 italic text-center py-2">
                        No comments yet. Be the first to reply!
                      </p>
                    ) : (
                      post.comments.map((c) => (
                        <div key={c.id} className="flex items-start gap-2 bg-[#161616] p-2.5 rounded-xl">
                          <img src={c.userAvatar} className="w-6 h-6 rounded-full object-cover" />
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-semibold text-slate-200">{c.userName}</span>
                              <span className="text-[10px] text-slate-500">{c.timestamp}</span>
                            </div>
                            <p className="text-xs text-slate-300 mt-0.5">{c.text}</p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Add Comment Input */}
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      placeholder="Write a comment..."
                      className="flex-1 bg-[#161616] border border-white/5 rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    />
                    <button
                      onClick={() => handleCommentSubmit(post.id)}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white p-1.5 rounded-xl text-xs"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

            </article>
          );
        })}
      </div>

      {/* Story Fullscreen Viewer Modal */}
      {activeStory && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="relative max-w-sm w-full bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
            <button
              onClick={() => setActiveStory(null)}
              className="absolute top-4 right-4 bg-black/60 text-white p-1.5 rounded-full z-10 hover:bg-black/80"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 p-4 absolute top-0 left-0 right-0 bg-gradient-to-b from-black/80 to-transparent z-10">
              <img src={activeStory.userAvatar} className="w-8 h-8 rounded-full border border-white" />
              <div>
                <h4 className="text-xs font-bold text-white">{activeStory.userName}</h4>
                <p className="text-[10px] text-zinc-300">{activeStory.timestamp}</p>
              </div>
            </div>

            <img src={activeStory.mediaUrl} className="w-full h-96 object-cover" />

            <div className="p-4 bg-zinc-900">
              <p className="text-xs text-zinc-200">{activeStory.caption}</p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
