import React from "react";
import { useApp } from "../context/AppContext";
import { 
  MessageSquare, 
  PhoneCall, 
  Rss, 
  Users, 
  User as UserIcon, 
  Sparkles, 
  Wifi, 
  WifiOff, 
  PhoneIncoming,
  ChevronDown,
  Search
} from "lucide-react";

export const Navbar: React.FC = () => {
  const { 
    currentUser, 
    users, 
    switchUser, 
    wsConnected, 
    activeCall, 
    setActiveTab, 
    activeTab 
  } = useApp();

  return (
    <header className="sticky top-0 z-40 bg-[#121212]/95 backdrop-blur-md border-b border-white/5 text-slate-200 px-4 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Brand Logo */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('feed')}>
          <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 font-bold text-xl tracking-wider">
            P
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-tight text-white">
              Pulse
            </h1>
            <p className="text-[10px] text-indigo-400 uppercase tracking-widest font-semibold -mt-1">
              Social & Call
            </p>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="hidden md:flex items-center flex-1 max-w-xs relative">
          <Search className="w-4 h-4 absolute left-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search posts, contacts, calls..."
            className="w-full bg-white/5 border border-white/5 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition"
          />
        </div>

        {/* Status / Active Call Banner / User Switcher */}
        <div className="flex items-center gap-3">
          
          {/* Active Call Quick Bar */}
          {activeCall && (
            <button
              onClick={() => setActiveTab('calls')}
              className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-3 py-1.5 rounded-full text-xs font-medium animate-pulse hover:bg-emerald-500/20 transition"
            >
              <PhoneIncoming className="w-3.5 h-3.5" />
              <span>Call with {activeCall.peerName} ({activeCall.status})</span>
            </button>
          )}

          {/* Connection Pill */}
          <div className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium border ${
            wsConnected 
              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
              : 'bg-amber-500/10 border-amber-500/20 text-amber-400'
          }`}>
            {wsConnected ? (
              <>
                <Wifi className="w-3 h-3 text-emerald-400" />
                <span>Live Connected</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3 h-3 text-amber-400" />
                <span>Connecting...</span>
              </>
            )}
          </div>

          {/* User Profile Switcher */}
          <div className="relative group">
            <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-full p-1 pr-3 cursor-pointer hover:bg-white/10 transition">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-7 h-7 rounded-full object-cover border border-indigo-500"
              />
              <span className="text-xs font-medium text-slate-200 hidden sm:inline">
                {currentUser.name}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </div>

            {/* Dropdown Menu to Impersonate/Switch User */}
            <div className="absolute right-0 top-full mt-2 w-56 bg-[#161616] border border-white/10 rounded-xl shadow-2xl py-2 hidden group-hover:block z-50">
              <div className="px-3 py-1.5 border-b border-white/5">
                <p className="text-[11px] text-slate-400 uppercase font-semibold tracking-wider">
                  Switch Active Account
                </p>
                <p className="text-xs text-slate-500">Test real-time chat & calls between users</p>
              </div>

              <div className="max-h-60 overflow-y-auto py-1">
                {users.map((user) => (
                  <button
                    key={user.id}
                    onClick={() => switchUser(user.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/5 transition ${
                      user.id === currentUser.id ? 'bg-indigo-500/10 text-indigo-400 font-medium' : 'text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <img src={user.avatar} className="w-6 h-6 rounded-full object-cover" />
                      <div>
                        <div className="font-medium flex items-center gap-1">
                          {user.name}
                          {user.isAi && <Sparkles className="w-3 h-3 text-indigo-400" />}
                        </div>
                        <div className="text-[10px] text-slate-500">@{user.username}</div>
                      </div>
                    </div>
                    {user.id === currentUser.id && (
                      <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

        </div>

      </div>
    </header>
  );
};
