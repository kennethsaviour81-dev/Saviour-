import React from "react";
import { useApp } from "../context/AppContext";
import { 
  PhoneCall, 
  Video, 
  PhoneIncoming, 
  PhoneOutgoing, 
  PhoneMissed, 
  Clock, 
  Plus, 
  Sparkles, 
  UserCheck 
} from "lucide-react";

export const CallsView: React.FC = () => {
  const { users, currentUser, callLogs, initiateCall } = useApp();

  const contacts = users.filter((u) => u.id !== currentUser.id);

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      
      {/* Header Banner & Room Launcher */}
      <div className="bg-[#121212] border border-white/5 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center md:text-left">
          <div className="inline-flex items-center gap-1.5 bg-indigo-500/20 text-indigo-300 px-2.5 py-0.5 rounded-full text-[10px] font-semibold border border-indigo-500/30">
            <Sparkles className="w-3 h-3 text-indigo-400" />
            <span>High Fidelity WebRTC Audio & Video</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">Calls & Meeting Rooms</h2>
          <p className="text-xs text-slate-300 max-w-md">
            Start a 1-on-1 crystal clear audio/video call or connect with Gemini AI Companion anytime.
          </p>
        </div>

        <button
          onClick={() => initiateCall("user-ai", "video")}
          className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-4 py-2.5 rounded-xl text-xs shadow-lg shadow-indigo-600/30 transition flex items-center gap-2 shrink-0"
        >
          <Video className="w-4 h-4" />
          <span>Call Gemini AI Companion</span>
        </button>
      </div>

      {/* Quick Dial Grid */}
      <div className="bg-[#121212] border border-white/5 rounded-2xl p-5 space-y-4 shadow-lg">
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
          Quick Contact Dialing
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {contacts.map((contact) => (
            <div
              key={contact.id}
              className="bg-[#161616] border border-white/5 p-3.5 rounded-xl flex items-center justify-between hover:border-white/10 transition"
            >
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img src={contact.avatar} className="w-9 h-9 rounded-full object-cover border border-white/10" />
                  <span
                    className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-[#121212] ${
                      contact.status === 'online' ? 'bg-emerald-500' : 'bg-slate-500'
                    }`}
                  />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1">
                    {contact.name}
                    {contact.isAi && <Sparkles className="w-3 h-3 text-indigo-400" />}
                  </h4>
                  <p className="text-[10px] text-slate-400">@{contact.username}</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => initiateCall(contact.id, "audio")}
                  className="p-2 rounded-lg bg-white/5 text-slate-300 hover:bg-indigo-600 hover:text-white transition"
                  title="Audio Call"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => initiateCall(contact.id, "video")}
                  className="p-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-500 shadow-md transition"
                  title="Video Call"
                >
                  <Video className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Calls Log */}
      <div className="bg-[#121212] border border-white/5 rounded-2xl p-5 space-y-4 shadow-lg">
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>Recent Call Activity</span>
        </h3>

        <div className="divide-y divide-white/5">
          {callLogs.map((log) => {
            const isOutgoing = log.callerId === currentUser.id;
            const otherUserId = isOutgoing ? log.receiverId : log.callerId;
            const otherUser = users.find((u) => u.id === otherUserId) || users[0];

            return (
              <div key={log.id} className="py-3.5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img src={otherUser.avatar} className="w-9 h-9 rounded-full object-cover border border-white/10" />
                  <div>
                    <h4 className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                      {isOutgoing ? (
                        <PhoneOutgoing className="w-3 h-3 text-indigo-400" />
                      ) : (
                        <PhoneIncoming className="w-3 h-3 text-emerald-400" />
                      )}
                      <span>{otherUser.name}</span>
                    </h4>
                    <p className="text-[10px] text-slate-500">
                      {log.timestamp} • {Math.floor(log.durationSeconds / 60)}m {log.durationSeconds % 60}s
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => initiateCall(otherUser.id, log.type)}
                  className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-xs font-medium text-slate-200 rounded-lg transition"
                >
                  Redial
                </button>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
