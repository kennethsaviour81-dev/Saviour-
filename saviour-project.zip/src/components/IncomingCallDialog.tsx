import React from "react";
import { useApp } from "../context/AppContext";
import { PhoneCall, Video, PhoneOff, Sparkles } from "lucide-react";

export const IncomingCallDialog: React.FC = () => {
  const { incomingCall, acceptIncomingCall, declineIncomingCall } = useApp();

  if (!incomingCall) return null;

  return (
    <div className="fixed top-6 right-6 z-50 max-w-md w-full bg-[#161616] border-2 border-indigo-500 rounded-2xl p-4 shadow-2xl animate-bounce">
      <div className="flex items-center gap-4">
        
        <div className="relative shrink-0">
          <img
            src={incomingCall.peerAvatar}
            alt={incomingCall.peerName}
            className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500"
          />
          <span className="absolute inset-0 rounded-full border-2 border-indigo-400 animate-ping opacity-75" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-400">
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Incoming {incomingCall.type === 'video' ? 'Video' : 'Voice'} Call</span>
          </div>
          <h3 className="text-sm font-bold text-white truncate">{incomingCall.peerName}</h3>
          <p className="text-[11px] text-slate-400">Ringing...</p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={declineIncomingCall}
            className="p-2.5 bg-red-600 hover:bg-red-500 text-white rounded-full transition"
            title="Decline Call"
          >
            <PhoneOff className="w-4 h-4" />
          </button>

          <button
            onClick={acceptIncomingCall}
            className="p-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full transition shadow-lg shadow-emerald-600/30 animate-pulse"
            title="Accept Call"
          >
            {incomingCall.type === 'video' ? <Video className="w-4 h-4" /> : <PhoneCall className="w-4 h-4" />}
          </button>
        </div>

      </div>
    </div>
  );
};
