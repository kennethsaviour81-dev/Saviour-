import React, { useState, useRef, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { 
  PhoneCall, 
  Video, 
  Send, 
  Mic, 
  Square, 
  Image as ImageIcon, 
  Sparkles, 
  Search, 
  Smile, 
  Play, 
  Pause,
  CheckCheck
} from "lucide-react";

export const ChatsView: React.FC = () => {
  const { 
    currentUser, 
    users, 
    messages, 
    sendMessage, 
    activeConversationUserId, 
    setActiveConversationUserId,
    initiateCall,
    setSelectedProfileUserId,
    setActiveTab
  } = useApp();

  const [messageText, setMessageText] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activePeer = users.find((u) => u.id === activeConversationUserId) || users[1];

  const convKey = `${currentUser.id}_${activePeer.id}`;
  const conversationMessages = messages[convKey] || [];

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversationMessages]);

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;
    sendMessage(activePeer.id, messageText.trim());
    setMessageText("");
  };

  // Record Voice Note
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        const audioUrl = URL.createObjectURL(audioBlob);
        sendMessage(activePeer.id, undefined, undefined, audioUrl);
        stream.getTracks().forEach((t) => t.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingDuration(0);

      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (e) {
      console.error("Microphone access error", e);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      clearInterval(timerRef.current);
    }
  };

  const filteredUsers = users
    .filter((u) => u.id !== currentUser.id)
    .filter((u) => u.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="h-[calc(100vh-6rem)] bg-[#121212] border border-white/5 rounded-2xl overflow-hidden flex flex-col md:flex-row shadow-2xl">
      
      {/* Left Pane: Conversations List */}
      <div className="w-full md:w-80 bg-[#121212] border-b md:border-b-0 md:border-r border-white/5 flex flex-col shrink-0">
        
        <div className="p-4 border-b border-white/5 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-sm text-slate-100">Messages</h2>
            <span className="text-[10px] text-slate-400 font-mono bg-white/5 px-2 py-0.5 rounded-full">
              Real-time
            </span>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search conversations..."
              className="w-full bg-[#161616] border border-white/5 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-white/5">
          {filteredUsers.map((user) => {
            const isSelected = user.id === activePeer.id;
            const key = `${currentUser.id}_${user.id}`;
            const userMsgs = messages[key] || [];
            const lastMsg = userMsgs[userMsgs.length - 1];

            return (
              <div
                key={user.id}
                onClick={() => setActiveConversationUserId(user.id)}
                className={`p-3.5 flex items-center gap-3 cursor-pointer transition ${
                  isSelected ? 'bg-indigo-600/15 border-l-4 border-indigo-500' : 'hover:bg-white/5'
                }`}
              >
                <div className="relative">
                  <img src={user.avatar} className="w-10 h-10 rounded-full object-cover border border-white/10" />
                  <span
                    className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#121212] ${
                      user.status === 'online' ? 'bg-emerald-500' : 'bg-slate-500'
                    }`}
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-semibold text-slate-200 truncate flex items-center gap-1">
                      {user.name}
                      {user.isAi && <Sparkles className="w-3 h-3 text-indigo-400" />}
                    </h4>
                    {lastMsg && <span className="text-[10px] text-slate-500">{lastMsg.timestamp}</span>}
                  </div>

                  <p className="text-[11px] text-slate-400 truncate mt-0.5">
                    {lastMsg ? (lastMsg.text || (lastMsg.audioUrl ? "🎤 Voice note" : "Sent media")) : user.bio}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Pane: Active Chat Window */}
      <div className="flex-1 flex flex-col bg-[#0A0A0A]">
        
        {/* Chat Header */}
        <div className="p-3.5 border-b border-white/5 bg-[#121212] flex items-center justify-between">
          <div
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => {
              setSelectedProfileUserId(activePeer.id);
              setActiveTab('profile');
            }}
          >
            <div className="relative">
              <img src={activePeer.avatar} className="w-9 h-9 rounded-full object-cover border border-white/10" />
              <span
                className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-[#121212] ${
                  activePeer.status === 'online' ? 'bg-emerald-500' : 'bg-slate-500'
                }`}
              />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-100 flex items-center gap-1 hover:underline">
                {activePeer.name}
                {activePeer.isAi && <Sparkles className="w-3 h-3 text-indigo-400" />}
              </h3>
              <p className="text-[10px] text-slate-400">
                {activePeer.status === 'online' ? 'Active now' : 'Offline'}
              </p>
            </div>
          </div>

          {/* Quick Voice & Video Call Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => initiateCall(activePeer.id, 'audio')}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-indigo-400 transition"
              title="Start Voice Call"
            >
              <PhoneCall className="w-4 h-4" />
            </button>

            <button
              onClick={() => initiateCall(activePeer.id, 'video')}
              className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md transition"
              title="Start Video Call"
            >
              <Video className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {conversationMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-2 text-slate-500">
              <Sparkles className="w-8 h-8 text-indigo-400/50" />
              <p className="text-xs font-medium">Say hello to {activePeer.name}!</p>
              <p className="text-[11px] max-w-xs text-slate-600">
                Send a message, audio voice note, or start a real-time voice call.
              </p>
            </div>
          ) : (
            conversationMessages.map((msg) => {
              const isMine = msg.senderId === currentUser.id;

              return (
                <div
                  key={msg.id}
                  className={`flex items-end gap-2 ${isMine ? 'justify-end' : 'justify-start'}`}
                >
                  {!isMine && (
                    <img src={activePeer.avatar} className="w-6 h-6 rounded-full object-cover" />
                  )}

                  <div
                    className={`max-w-xs md:max-w-md px-3.5 py-2 rounded-2xl text-xs space-y-1 ${
                      isMine
                        ? 'bg-indigo-600 text-white rounded-br-none shadow-md shadow-indigo-600/10'
                        : 'bg-[#161616] text-slate-100 rounded-bl-none border border-white/5'
                    }`}
                  >
                    {msg.text && <p className="leading-relaxed">{msg.text}</p>}

                    {/* Voice Note Audio Component */}
                    {msg.audioUrl && (
                      <div className="flex items-center gap-2 py-1">
                        <audio src={msg.audioUrl} controls className="h-7 w-48 text-xs" />
                      </div>
                    )}

                    <div className="flex items-center justify-end gap-1 text-[9px] opacity-70">
                      <span>{msg.timestamp}</span>
                      {isMine && <CheckCheck className="w-3 h-3 text-indigo-200" />}
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Controls Bar */}
        <div className="p-3 bg-[#121212] border-t border-white/5">
          
          {isRecording ? (
            <div className="flex items-center justify-between bg-red-500/10 border border-red-500/30 p-2 rounded-xl text-red-400">
              <div className="flex items-center gap-2 text-xs font-medium animate-pulse">
                <Mic className="w-4 h-4" />
                <span>Recording voice note... ({recordingDuration}s)</span>
              </div>

              <button
                onClick={stopRecording}
                className="bg-red-600 text-white px-3 py-1 rounded-lg text-xs font-semibold hover:bg-red-500 flex items-center gap-1"
              >
                <Square className="w-3.5 h-3.5" />
                <span>Send Note</span>
              </button>
            </div>
          ) : (
            <form onSubmit={handleSendText} className="flex items-center gap-2">
              <button
                type="button"
                onClick={startRecording}
                className="p-2 text-slate-400 hover:text-indigo-400 hover:bg-white/5 rounded-xl transition"
                title="Record Voice Note"
              >
                <Mic className="w-4 h-4" />
              </button>

              <input
                type="text"
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder={`Message ${activePeer.name}...`}
                className="flex-1 bg-[#161616] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition"
              />

              <button
                type="submit"
                disabled={!messageText.trim()}
                className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white p-2 rounded-xl text-xs font-semibold shadow-md transition"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          )}

        </div>

      </div>

    </div>
  );
};
