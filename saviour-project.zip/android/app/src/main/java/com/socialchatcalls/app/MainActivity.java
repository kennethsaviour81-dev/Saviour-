package com.socialchatcalls.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
