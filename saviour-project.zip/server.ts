import express from "express";
import http from "http";
import path from "path";
import { WebSocketServer, WebSocket } from "ws";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Initialize Gemini Client server-side
const geminiApiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (geminiApiKey) {
  ai = new GoogleGenAI({ apiKey: geminiApiKey });
}

const app = express();
app.use(express.json());

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

// INITIAL SEED DATA
const INITIAL_USERS = [
  {
    id: "user-1",
    name: "Alex Rivera",
    username: "alex_r",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250",
    status: "online",
    bio: "Product Designer & Tech Explorer 🚀 | Building human-centered UI/UX",
    followersCount: 1420,
    followingCount: 380,
  },
  {
    id: "user-2",
    name: "Sarah Chen",
    username: "sarah_c",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=250",
    status: "online",
    bio: "Full Stack Developer 💻 | AI enthusiast & coffee addict ☕",
    followersCount: 2890,
    followingCount: 512,
  },
  {
    id: "user-3",
    name: "Elena Rostova",
    username: "elena_r",
    avatar: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=250",
    status: "online",
    bio: "Digital Nomad & Landscape Photographer 📷 | Living between Tokyo & Zurich",
    followersCount: 5600,
    followingCount: 210,
  },
  {
    id: "user-4",
    name: "Marcus Vance",
    username: "marcus_v",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250",
    status: "away",
    bio: "Audio Engineer & Producer 🎧 | Creating ambient synth landscapes",
    followersCount: 940,
    followingCount: 180,
  },
  {
    id: "user-ai",
    name: "Gemini AI Companion",
    username: "gemini_ai",
    avatar: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=250",
    status: "online",
    bio: "Your intelligent assistant on Social Pulse 🤖 | Always here to chat, brainstorm or voice call!",
    followersCount: 99000,
    followingCount: 1,
    isAi: true,
  },
];

const INITIAL_STORIES = [
  {
    id: "story-1",
    userId: "user-2",
    userName: "Sarah Chen",
    userAvatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=250",
    mediaUrl: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=800",
    caption: "Late night coding session with fresh dark roast ☕💻",
    timestamp: "2 hours ago",
  },
  {
    id: "story-2",
    userId: "user-3",
    userName: "Elena Rostova",
    userAvatar: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=250",
    mediaUrl: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&q=80&w=800",
    caption: "Sunrise hike near Lake Lucerne ✨ Mountain air hits different",
    timestamp: "4 hours ago",
  },
  {
    id: "story-3",
    userId: "user-4",
    userName: "Marcus Vance",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250",
    mediaUrl: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&q=80&w=800",
    caption: "Studio analog synth rack testing 🎶",
    timestamp: "6 hours ago",
  },
];

let POSTS = [
  {
    id: "post-1",
    userId: "user-3",
    userName: "Elena Rostova",
    userAvatar: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=250",
    content: "Captured the golden hour over Mount Fuji this evening! The sky looked like liquid gold. What's your favorite photography spot in Asia?",
    imageUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&q=80&w=1000",
    likes: ["user-1", "user-2", "user-4"],
    comments: [
      {
        id: "c-1",
        userId: "user-1",
        userName: "Alex Rivera",
        userAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250",
        text: "Stunning colors! The depth of field is incredible.",
        timestamp: "10m ago",
      },
    ],
    sharesCount: 14,
    timestamp: "1 hour ago",
    tags: ["Photography", "Japan", "Travel"],
  },
  {
    id: "post-2",
    userId: "user-2",
    userName: "Sarah Chen",
    userAvatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=250",
    content: "Just shipped WebSockets & WebRTC peer-to-peer real-time audio calling on our platform! The feeling when a zero-latency audio connection establishes is unmatched. 🚀📱",
    likes: ["user-1", "user-3"],
    comments: [],
    sharesCount: 5,
    timestamp: "3 hours ago",
    tags: ["Engineering", "WebSockets", "WebRTC"],
  },
];

let MESSAGES: Record<string, any[]> = {
  "user-1_user-2": [
    {
      id: "m-1",
      senderId: "user-2",
      receiverId: "user-1",
      text: "Hey Alex! Did you see the new design system updates?",
      timestamp: "10:15 AM",
      status: "read",
    },
    {
      id: "m-2",
      senderId: "user-1",
      receiverId: "user-2",
      text: "Yes! The dark mode tokens and glassmorphic cards look super clean.",
      timestamp: "10:18 AM",
      status: "read",
    },
    {
      id: "m-3",
      senderId: "user-2",
      receiverId: "user-1",
      text: "Awesome! Let's do a quick voice call later to review the audio calling UI.",
      timestamp: "10:20 AM",
      status: "read",
    },
  ],
  "user-1_user-ai": [
    {
      id: "mai-1",
      senderId: "user-ai",
      receiverId: "user-1",
      text: "Hello Alex! 👋 I'm your Gemini AI companion. Ask me anything, or tap the Voice Call button to talk live!",
      timestamp: "09:00 AM",
      status: "read",
    },
  ],
};

let CALL_LOGS = [
  {
    id: "call-1",
    callerId: "user-2",
    receiverId: "user-1",
    type: "video" as const,
    status: "completed" as const,
    durationSeconds: 245,
    timestamp: "Yesterday, 4:30 PM",
  },
  {
    id: "call-2",
    callerId: "user-1",
    receiverId: "user-3",
    type: "audio" as const,
    status: "completed" as const,
    durationSeconds: 112,
    timestamp: "2 days ago",
  },
];

// Active WebSocket connections map: userId -> Set<WebSocket>
const connectedUsers = new Map<string, Set<WebSocket>>();

function broadcast(data: any, excludeUserId?: string) {
  const json = JSON.stringify(data);
  for (const [userId, sockets] of connectedUsers.entries()) {
    if (excludeUserId && userId === excludeUserId) continue;
    for (const ws of sockets) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(json);
      }
    }
  }
}

function sendToUser(userId: string, data: any) {
  const sockets = connectedUsers.get(userId);
  if (sockets) {
    const json = JSON.stringify(data);
    for (const ws of sockets) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(json);
      }
    }
  }
}

// WEBSOCKET LOGIC
wss.on("connection", (ws) => {
  let registeredUserId: string | null = null;

  ws.on("message", async (rawMessage) => {
    try {
      const data = JSON.parse(rawMessage.toString());

      switch (data.type) {
        case "register": {
          registeredUserId = data.userId;
          if (!connectedUsers.has(registeredUserId)) {
            connectedUsers.set(registeredUserId, new Set());
          }
          connectedUsers.get(registeredUserId)!.add(ws);

          // Update user status online
          broadcast({
            type: "status_changed",
            userId: registeredUserId,
            status: "online",
          });
          break;
        }

        case "chat_message": {
          const msg = data.message;
          const convKey1 = `${msg.senderId}_${msg.receiverId}`;
          const convKey2 = `${msg.receiverId}_${msg.senderId}`;

          if (!MESSAGES[convKey1]) MESSAGES[convKey1] = [];
          if (!MESSAGES[convKey2]) MESSAGES[convKey2] = [];

          MESSAGES[convKey1].push(msg);
          if (convKey1 !== convKey2) MESSAGES[convKey2].push(msg);

          // Deliver real-time message to recipient
          sendToUser(msg.receiverId, {
            type: "chat_message",
            message: msg,
          });

          // AI Auto-reply handler if recipient is AI companion
          if (msg.receiverId === "user-ai" && ai) {
            setTimeout(async () => {
              try {
                const response = await ai!.models.generateContent({
                  model: "gemini-2.5-flash",
                  contents: [
                    {
                      role: "user",
                      parts: [
                        {
                          text: `You are Gemini AI Companion on a modern social media app with video/voice calling. The user says: "${msg.text || "Sent a media file"}". Respond in a warm, friendly, engaging social chat style. Keep it under 3 sentences.`,
                        },
                      ],
                    },
                  ],
                });

                const replyText = response.text || "That's wonderful! Tell me more about what you're working on.";
                const aiMsg = {
                  id: "ai-msg-" + Date.now(),
                  senderId: "user-ai",
                  receiverId: msg.senderId,
                  text: replyText,
                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                  status: "read",
                };

                MESSAGES[convKey1].push(aiMsg);
                if (convKey1 !== convKey2) MESSAGES[convKey2].push(aiMsg);

                sendToUser(msg.senderId, {
                  type: "chat_message",
                  message: aiMsg,
                });
              } catch (e) {
                console.error("AI reply error", e);
              }
            }, 1000);
          }
          break;
        }

        case "typing": {
          sendToUser(data.receiverId, data);
          break;
        }

        case "post_created": {
          POSTS.unshift(data.post);
          broadcast({ type: "post_created", post: data.post });
          break;
        }

        case "post_liked": {
          const targetPost = POSTS.find((p) => p.id === data.postId);
          if (targetPost) {
            if (targetPost.likes.includes(data.userId)) {
              targetPost.likes = targetPost.likes.filter((id) => id !== data.userId);
            } else {
              targetPost.likes.push(data.userId);
            }
            broadcast({ type: "post_liked", postId: data.postId, userId: data.userId });
          }
          break;
        }

        case "comment_added": {
          const targetPost = POSTS.find((p) => p.id === data.postId);
          if (targetPost) {
            targetPost.comments.push(data.comment);
            broadcast({ type: "comment_added", postId: data.postId, comment: data.comment });
          }
          break;
        }

        // WebRTC & Call Signaling
        case "call_initiate":
        case "call_accept":
        case "call_decline":
        case "call_end":
        case "webrtc_signal": {
          const targetId = data.receiverId || data.targetUserId || data.peerId;
          if (targetId) {
            sendToUser(targetId, data);
          }
          break;
        }
      }
    } catch (err) {
      console.error("WS error:", err);
    }
  });

  ws.on("close", () => {
    if (registeredUserId) {
      const userSockets = connectedUsers.get(registeredUserId);
      if (userSockets) {
        userSockets.delete(ws);
        if (userSockets.size === 0) {
          connectedUsers.delete(registeredUserId);
          broadcast({
            type: "status_changed",
            userId: registeredUserId,
            status: "offline",
          });
        }
      }
    }
  });
});

// REST API ROUTES
app.get("/api/initial-data", (req, res) => {
  res.json({
    users: INITIAL_USERS,
    stories: INITIAL_STORIES,
    posts: POSTS,
    messages: MESSAGES,
    callLogs: CALL_LOGS,
  });
});

app.post("/api/posts", (req, res) => {
  const newPost = req.body;
  POSTS.unshift(newPost);
  broadcast({ type: "post_created", post: newPost });
  res.json({ success: true, post: newPost });
});

app.post("/api/posts/:id/like", (req, res) => {
  const { id } = req.params;
  const { userId } = req.body;
  const post = POSTS.find((p) => p.id === id);
  if (post) {
    if (post.likes.includes(userId)) {
      post.likes = post.likes.filter((u) => u !== userId);
    } else {
      post.likes.push(userId);
    }
    broadcast({ type: "post_liked", postId: id, userId });
    return res.json({ success: true, likes: post.likes });
  }
  res.status(404).json({ error: "Post not found" });
});

app.post("/api/posts/:id/comment", (req, res) => {
  const { id } = req.params;
  const comment = req.body;
  const post = POSTS.find((p) => p.id === id);
  if (post) {
    post.comments.push(comment);
    broadcast({ type: "comment_added", postId: id, comment });
    return res.json({ success: true, comments: post.comments });
  }
  res.status(404).json({ error: "Post not found" });
});

// AI Prompt / Post Generator Endpoint
app.post("/api/ai/generate-post", async (req, res) => {
  const { topic, style } = req.body;
  if (!ai) {
    return res.json({
      text: `Excited to explore ${topic || "new ideas"} today! Innovation happens when community and high performance converge. ✨ #SocialPulse #Tech`,
    });
  }

  try {
    const prompt = `Write a creative, engaging social media post about "${topic || "building connected real-time applications"}". Tone: ${style || "inspiring"}. Keep it under 280 characters with 2 relevant hashtags. Do not use quotes around the post.`;
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    res.json({ text: response.text?.trim() || "Building the future of social communication!" });
  } catch (err: any) {
    console.error("AI post generation error", err);
    res.json({ text: `Exploring ${topic || "technology"} with the community! 🚀` });
  }
});

// VITE SERVING / PRODUCTION BUILD
async function startServer() {
  const PORT = 3000;

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
